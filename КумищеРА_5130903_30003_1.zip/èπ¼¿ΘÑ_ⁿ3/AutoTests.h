#pragma once
#include "Functions.h"
#include "triangle.h"

void getPointsInLine_TEST();
void getFarestPoint_TEST();
void getMaxLengthTriangle_TEST();
template<typename T> void Check(T& res, T& c);